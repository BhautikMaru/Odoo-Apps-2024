from . import shopify_connector
from . import res_partner
from . import product_template
from . import product_product
from . import product_attribute
from . import product_category
from . import sale_order
from . import shopify_webhook
from . import shopify_sale_order_process_configuration
# from . import rcs_shopify_payment_gateway
from . import sale_order_automation
from . import stock
from . import shopify_queue
from . import shopify_queue_line
